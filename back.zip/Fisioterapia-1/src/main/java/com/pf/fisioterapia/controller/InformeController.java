package com.pf.fisioterapia.controller;

import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.Informe;
import com.pf.fisioterapia.service.InformeService;

@RestController
@RequestMapping("/informes")
public class InformeController {

    private final InformeService informeService;

    public InformeController(InformeService informeService) {
        this.informeService = informeService;
    }

    @GetMapping("/{id}")
    public Informe getInforme(@PathVariable Long id) {
        return informeService.getById(id);
    }

    @GetMapping
    public List<Informe> getAllInformes() {
        return informeService.getAll();
    }

    @PostMapping
    public Informe createInforme(@RequestBody Informe informe) {
        return informeService.save(informe);
    }

    @PutMapping("/{id}")
    public Informe updateInforme(@PathVariable Long id, @RequestBody Informe informe) {
        return informeService.save(informe);
    }

    @DeleteMapping("/{id}")
    public void deleteInforme(@PathVariable Long id) {
        informeService.deleteById(id);
    }
}
