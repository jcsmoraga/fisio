package com.pf.fisioterapia.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "paciente_patologias")
@Data
@IdClass(PacientePatologiaId.class)
public class PacientePatologia {

    @Id
    @ManyToOne
    @JoinColumn(name = "id_paciente", nullable = false)
    private Paciente paciente;

    @Id
    @ManyToOne
    @JoinColumn(name = "id_patologia", nullable = false)
    private Patologia patologia;
}
