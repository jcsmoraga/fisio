package com.pf.fisioterapia.model;

import java.io.Serializable;

import lombok.Data;

@Data
public class PacientePatologiaId implements Serializable {
    private Long paciente;
    private Long patologia;
}
