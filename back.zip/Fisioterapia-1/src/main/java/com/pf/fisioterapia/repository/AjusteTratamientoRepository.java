package com.pf.fisioterapia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pf.fisioterapia.model.AjusteTratamiento;

@Repository
public interface AjusteTratamientoRepository extends JpaRepository<AjusteTratamiento, Long> {
}
