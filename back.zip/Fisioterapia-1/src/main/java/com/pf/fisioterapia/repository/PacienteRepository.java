package com.pf.fisioterapia.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pf.fisioterapia.model.Paciente;

public interface PacienteRepository extends JpaRepository<Paciente, Long>  {
	
	List<Paciente> findByNombreContainingIgnoreCaseOrApellidoContainingIgnoreCase(String nombre, String apellido);
}
