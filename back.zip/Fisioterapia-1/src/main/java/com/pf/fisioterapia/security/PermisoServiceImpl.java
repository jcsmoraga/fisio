package com.pf.fisioterapia.security;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class PermisoServiceImpl implements PermisoService {

    private final PermisoRepository permisoRepository;

    public PermisoServiceImpl(PermisoRepository permisoRepository) {
        this.permisoRepository = permisoRepository;
    }

    @Override
    public Permiso save(Permiso permiso) {
        return permisoRepository.save(permiso);
    }

    @Override
    public Permiso getById(Long id) {
        return permisoRepository.findById(id).orElse(null);
    }

    @Override
    public List<Permiso> getAll() {
        return permisoRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        permisoRepository.deleteById(id);
    }
}