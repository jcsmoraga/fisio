package com.pf.fisioterapia.security;

import java.util.List;

public interface RolService {
    Rol save(Rol rol);
    Rol getById(Long id);
    List<Rol> getAll();
    void deleteById(Long id);
}
