package com.pf.fisioterapia.security;

import java.util.List;

public interface UsuarioService {
    Usuario save(Usuario usuario);
    Usuario getById(Long id);
    List<Usuario> getAll();
    void deleteById(Long id);
    Usuario findByEmail(String email);
}