package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Fisioterapeuta;

public interface FisioterapeutaService {

	Fisioterapeuta getFisioterapeuta(Long id); 
	List<Fisioterapeuta> getAllFisioterapeutas();
	Fisioterapeuta saveFisioterapeuta(Fisioterapeuta fisioterapeuta);
	String deleteFisioterapeuta(Long id);
	List<Fisioterapeuta> searchFisioterapeutas(String query);
}
