package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.Patologia;
import com.pf.fisioterapia.repository.PatologiaRepository;
import com.pf.fisioterapia.service.PatologiaService;

@Service
public class PatologiaServiceImpl implements PatologiaService {

    private final PatologiaRepository patologiaRepository;

    public PatologiaServiceImpl(PatologiaRepository patologiaRepository) {
        this.patologiaRepository = patologiaRepository;
    }

    @Override
    public Patologia save(Patologia patologia) {
        return patologiaRepository.save(patologia);
    }

    @Override
    public Patologia getById(Long id) {
        return patologiaRepository.findById(id).orElse(null);
    }

    @Override
    public List<Patologia> getAll() {
        return patologiaRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        patologiaRepository.deleteById(id);
    }
}
