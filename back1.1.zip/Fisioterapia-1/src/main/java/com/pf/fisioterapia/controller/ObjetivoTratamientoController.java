package com.pf.fisioterapia.controller;


import java.util.List;

import org.springframework.web.bind.annotation.*;

import com.pf.fisioterapia.model.ObjetivoTratamiento;
import com.pf.fisioterapia.service.ObjetivoTratamientoService;

@RestController
@RequestMapping("/objetivos-tratamiento")
public class ObjetivoTratamientoController {

    private final ObjetivoTratamientoService objetivoTratamientoService;

    public ObjetivoTratamientoController(ObjetivoTratamientoService objetivoTratamientoService) {
        this.objetivoTratamientoService = objetivoTratamientoService;
    }

    @GetMapping("/{id}")
    public ObjetivoTratamiento getObjetivoTratamiento(@PathVariable Long id) {
        return objetivoTratamientoService.getById(id);
    }

    @GetMapping
    public List<ObjetivoTratamiento> getAllObjetivosTratamiento() {
        return objetivoTratamientoService.getAll();
    }

    @PostMapping
    public ObjetivoTratamiento createObjetivoTratamiento(@RequestBody ObjetivoTratamiento objetivoTratamiento) {
        return objetivoTratamientoService.save(objetivoTratamiento);
    }

    @PutMapping("/{id}")
    public ObjetivoTratamiento updateObjetivoTratamiento(@PathVariable Long id, @RequestBody ObjetivoTratamiento objetivoTratamiento) {
        return objetivoTratamientoService.save(objetivoTratamiento);
    }

    @DeleteMapping("/{id}")
    public void deleteObjetivoTratamiento(@PathVariable Long id) {
        objetivoTratamientoService.deleteById(id);
    }
}