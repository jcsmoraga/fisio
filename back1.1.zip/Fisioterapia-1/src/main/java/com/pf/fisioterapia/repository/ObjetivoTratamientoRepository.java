package com.pf.fisioterapia.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pf.fisioterapia.model.ObjetivoTratamiento;

@Repository
public interface ObjetivoTratamientoRepository extends JpaRepository<ObjetivoTratamiento, Long> {
}