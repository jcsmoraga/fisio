package com.pf.fisioterapia.security;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;

import java.util.Date;

public class JwtUtil {

   /* private String secretKey = "mySecretKey";  // Use a more secure secret in production
    private long expirationTime = 1000 * 60 * 60; // 1 hour
    
    // Generate token
    public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(SignatureAlgorithm.HS256, secretKey)
                .compact();
    }

    // Validate token
    public boolean validateToken(String token) {
        try {
            JwtParser parser = Jwts.parser()  // Corrected method for version 0.12.6
                .setSigningKey(secretKey);  // Set the signing key
            
            parser.parseClaimsJws(token);  // Parse and validate the JWT token
            return true;
        } catch (Exception e) {
            return false;  // Invalid token or parsing error
        }
    }

    // Extract username from token
    public String extractUsername(String token) {
        JwtParser parser = Jwts.parser()  // Corrected method for version 0.12.6
            .setSigningKey(secretKey);  // Set the signing key
        
        Claims claims = parser.parseClaimsJws(token).getBody();  // Parse the claims from the token
        
        return claims.getSubject();  // Get the username (subject) from claims
    }*/
}
