package com.pf.fisioterapia.security;



import java.util.List;

public interface PermisoService {
    Permiso save(Permiso permiso);
    Permiso getById(Long id);
    List<Permiso> getAll();
    void deleteById(Long id);
}