package com.pf.fisioterapia.security;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class RolServiceImpl implements RolService {

    private final RolRepository rolRepository;

    public RolServiceImpl(RolRepository rolRepository) {
        this.rolRepository = rolRepository;
    }

    @Override
    public Rol save(Rol rol) {
        return rolRepository.save(rol);
    }

    @Override
    public Rol getById(Long id) {
        return rolRepository.findById(id).orElse(null);
    }

    @Override
    public List<Rol> getAll() {
        return rolRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        rolRepository.deleteById(id);
    }
}
