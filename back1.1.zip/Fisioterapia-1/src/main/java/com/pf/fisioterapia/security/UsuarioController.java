package com.pf.fisioterapia.security;

import java.util.List;
import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pf.fisioterapia.response.ResponseHandler;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

	private final UsuarioService usuarioService;
	private final MessageSource messageSource;

	public UsuarioController(UsuarioService usuarioService, MessageSource messageSource) {
		this.usuarioService = usuarioService;
		this.messageSource = messageSource;
	}

	@GetMapping("/{id}")
	public UsuarioDTO getUsuario(@PathVariable Long id) {
		return usuarioService.getById(id);
	}

	@GetMapping
	public List<UsuarioDTO> getAllUsuarios() {
		return usuarioService.getAll();
	}

	@PostMapping
	public ResponseEntity<Object> createUsuario(@RequestBody Usuario usuario, Locale locale) {
		UsuarioDTO usuarioCreated = usuarioService.save(usuario);
		String successMessage = messageSource.getMessage("usuario.creation.success", null, locale);
		return ResponseHandler.responseBuilder(successMessage, HttpStatus.CREATED, usuarioCreated);
	}

	@PutMapping("/{email}")
	public ResponseEntity<Object> updateUsuario(@PathVariable String email, @RequestBody UsuarioDTO usuario, Locale locale) {
		UsuarioDTO usuarioUpdated = usuarioService.updateUsuario(usuario);
		String successMessage = messageSource.getMessage("usuario.update.success", null, locale);
		return ResponseHandler.responseBuilder(successMessage, HttpStatus.CREATED, usuarioUpdated);
	}

	@DeleteMapping("/{email}")
	public void deleteUsuario(@PathVariable String email) {
	    usuarioService.deleteByEmail(email);
	}
}
