package com.pf.fisioterapia.security;

public class UsuarioDTO {

    private String nombre;
    private String email;
    private int tipoUsuario;
    private boolean enabled;
    private String password;

    public UsuarioDTO(String nombre, String email, int tipoUsuario, boolean enabled, String password) {
        this.nombre = nombre;
        this.email = email;
        this.tipoUsuario = tipoUsuario;
        this.enabled = enabled;
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(int tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
