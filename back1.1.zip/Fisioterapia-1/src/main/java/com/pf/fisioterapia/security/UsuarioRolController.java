package com.pf.fisioterapia.security;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios-roles")
public class UsuarioRolController {

    private final UsuarioRolService usuarioRolService;

    public UsuarioRolController(UsuarioRolService usuarioRolService) {
        this.usuarioRolService = usuarioRolService;
    }

    @PostMapping
    public UsuarioRol createUsuarioRol(@RequestBody UsuarioRol usuarioRol) {
        return usuarioRolService.saveUsuarioRol(usuarioRol);
    }

    @DeleteMapping
    public void deleteUsuarioRol(@RequestBody UsuarioRol usuarioRol) {
        usuarioRolService.deleteUsuarioRol(usuarioRol);
    }
}