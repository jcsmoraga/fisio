package com.pf.fisioterapia.security;

import java.io.Serializable;



public class UsuarioRolId implements Serializable {
    private static final long serialVersionUID = 1L; 

    private Long usuario;
    private Long rol;
	public Long getUsuario() {
		return usuario;
	}
	public void setUsuario(Long usuario) {
		this.usuario = usuario;
	}
	public Long getRol() {
		return rol;
	}
	public void setRol(Long rol) {
		this.rol = rol;
	}
    
    
    
}
