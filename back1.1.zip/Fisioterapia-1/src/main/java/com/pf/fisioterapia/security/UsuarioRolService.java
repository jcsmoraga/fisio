package com.pf.fisioterapia.security;

public interface UsuarioRolService {

	 UsuarioRol saveUsuarioRol(UsuarioRol usuarioRol);
	 void deleteUsuarioRol(UsuarioRol usuarioRol);
}
