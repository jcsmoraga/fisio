package com.pf.fisioterapia.security;

import org.springframework.stereotype.Service;

@Service
public class UsuarioRolServiceImpl implements UsuarioRolService {

	private final  UsuarioRolRepository usuarioRolRepository;

	public UsuarioRolServiceImpl(UsuarioRolRepository usuarioRolRepository) {
	        this.usuarioRolRepository = usuarioRolRepository;
	}

	@Override
	public UsuarioRol saveUsuarioRol(UsuarioRol usuarioRol) {
		return usuarioRolRepository.save(usuarioRol);
	}

	@Override
	public void deleteUsuarioRol(UsuarioRol usuarioRol) {
		usuarioRolRepository.deleteById(null);
	}
}
