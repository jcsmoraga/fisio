package com.pf.fisioterapia.security;

import java.util.List;

public interface UsuarioService {
	UsuarioDTO save(Usuario usuario);
    UsuarioDTO getById(Long id);
    List<UsuarioDTO> getAll();
    void deleteByEmail(String email);
    Usuario findByEmail(String email);
	UsuarioDTO updateUsuario(UsuarioDTO usuarioDTO);
}