package com.pf.fisioterapia.security;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

	private final UsuarioRepository usuarioRepository;
	private final UsuarioRolRepository usuarioRolRepository;
	private final RolRepository rolRepository;

	public UsuarioServiceImpl(
			UsuarioRepository usuarioRepository,
			UsuarioRolRepository usuarioRolRepository,
			RolRepository rolRepository) {
		this.usuarioRepository = usuarioRepository;
		this.usuarioRolRepository = usuarioRolRepository;
		this.rolRepository = rolRepository;
	}

	@Override
	@Transactional  
	public UsuarioDTO save(Usuario usuario) {
	    Usuario usuarioCreated = usuarioRepository.save(usuario);
	    
	    Rol rol = rolRepository.findById(Long.valueOf(usuario.getTipoUsuario()))
	            .orElseThrow(() -> new IllegalArgumentException("Role not found for tipoUsuario"));

	    UsuarioRol usuarioRol = new UsuarioRol();
	    usuarioRol.setRol(rol);
	    usuarioRol.setUsuario(usuarioCreated);
	    usuarioRolRepository.save(usuarioRol);
	    return new UsuarioDTO(usuarioCreated.getNombre(),
	    					  usuarioCreated.getEmail(),
	                          usuarioCreated.getTipoUsuario(), 
	                          usuarioCreated.isEnabled(),
	                          usuarioCreated.getPassword());
	}

	@Override
	public UsuarioDTO getById(Long id) {
		Usuario usuario = usuarioRepository.findById(id).orElse(null);
		return new UsuarioDTO(
				usuario.getNombre(), 
				usuario.getEmail(), 
				usuario.getTipoUsuario(), 
				usuario.isEnabled(), 
				usuario.getPassword());
	}

	@Override
	public List<UsuarioDTO> getAll() {
		return usuarioRepository.findAll().stream().map(usuario -> new UsuarioDTO(
				usuario.getNombre(),
				usuario.getEmail(), 
				usuario.getTipoUsuario(), 
				usuario.isEnabled(), 
				usuario.getPassword()))
				.collect(Collectors.toList());
	}

	
	@Override
	public Usuario findByEmail(String email) {
		return usuarioRepository.findByEmail(email)
				.orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
	}
	
	@Override
	@Transactional
	public void deleteByEmail(String email) {
	    Usuario usuario = usuarioRepository.findByEmail(email)
	            .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));
	    deleteUsuarioRol(usuario);
	    usuarioRepository.delete(usuario);
	}

	private void deleteUsuarioRol(Usuario usuario) {
	    UsuarioRolId usuarioRolId = new UsuarioRolId();
	    usuarioRolId.setRol((long) usuario.getTipoUsuario());  
	    usuarioRolId.setUsuario(usuario.getId());
	    UsuarioRol usuarioRol = usuarioRolRepository.findById(usuarioRolId)
	            .orElseThrow(() -> new RuntimeException("Role not found for user with email: " + usuario.getEmail()));
	    usuarioRolRepository.delete(usuarioRol);
	}
	
	
	
	public UsuarioDTO updateUsuario(UsuarioDTO usuarioDTO) {
	    int updatedRows = usuarioRepository.updateUsuarioByEmail(usuarioDTO);

	    if (updatedRows > 0) {
	        Optional<Usuario> updatedUser = usuarioRepository.findByEmail(usuarioDTO.getEmail());

	        if (updatedUser.isPresent()) {
	            Usuario usuario = updatedUser.get();
	            return new UsuarioDTO(
	            		usuario.getNombre(), 
	            		usuario.getEmail(),
	                    usuario.getTipoUsuario(), 
	                    usuario.isEnabled(),
	                    usuario.getPassword());
	        } else {
	            throw new RuntimeException("User not found after update.");
	        }
	    } else {
	        throw new RuntimeException("User not found or update failed.");
	    }
	}
}
