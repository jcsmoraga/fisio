package com.pf.fisioterapia.service;

import java.util.List;

import com.pf.fisioterapia.model.Evaluacion;

public interface EvaluacionService {
    Evaluacion save(Evaluacion evaluacion);
    Evaluacion getById(Long id);
    List<Evaluacion> getAll();
    void deleteById(Long id);
}
