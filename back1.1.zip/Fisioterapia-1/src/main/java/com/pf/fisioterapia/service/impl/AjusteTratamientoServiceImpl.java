package com.pf.fisioterapia.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.pf.fisioterapia.model.AjusteTratamiento;
import com.pf.fisioterapia.repository.AjusteTratamientoRepository;
import com.pf.fisioterapia.service.AjusteTratamientoService;

@Service
public class AjusteTratamientoServiceImpl implements AjusteTratamientoService {

    private final AjusteTratamientoRepository ajusteTratamientoRepository;

    public AjusteTratamientoServiceImpl(AjusteTratamientoRepository ajusteTratamientoRepository) {
        this.ajusteTratamientoRepository = ajusteTratamientoRepository;
    }

    @Override
    public AjusteTratamiento getById(Long id) {
        return ajusteTratamientoRepository.findById(id).orElse(null);
    }

    @Override
    public List<AjusteTratamiento> getAll() {
        return ajusteTratamientoRepository.findAll();
    }

    @Override
    public void deleteById(Long id) {
        ajusteTratamientoRepository.deleteById(id);
    }

	@Override
	public AjusteTratamiento save(AjusteTratamiento ajusteTratamiento) {
		return null;
	}
}
