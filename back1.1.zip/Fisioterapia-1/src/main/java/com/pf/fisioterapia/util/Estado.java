package com.pf.fisioterapia.util;

public enum Estado {
    ACTIVO(0, "Activo"),
    FINALIZADO(1, "Finalizado"),
    PENDIENTE(2, "Pendiente");

    private final int value;
    private final String label;

    Estado(int value, String label) {
        this.value = value;
        this.label = label;
    }

    public int getValue() {
        return value;
    }

    public String getLabel() {
        return label;
    }

    public static Estado fromValue(int value) {
        for (Estado estado : Estado.values()) {
            if (estado.value == value) {
                return estado;
            }
        }
        throw new IllegalArgumentException("Unexpected value: " + value);
    }

    public static Estado fromLabel(String label) {
        for (Estado estado : Estado.values()) {
            if (estado.label.equalsIgnoreCase(label)) {
                return estado;
            }
        }
        throw new IllegalArgumentException("Unexpected label: " + label);
    }
}