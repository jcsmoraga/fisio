package com.pf.fe.fisioterapia.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

@Configuration
public class SecurityConfig {

	@Bean
	public AuthenticationSuccessHandler successHandler() {
		return new SimpleUrlAuthenticationSuccessHandler("/index.html");
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
		http.csrf().disable()
				.authorizeHttpRequests(auth -> auth
						.requestMatchers("/styles.css", "/menu.js", "*.html", "*.js",
								"/login", "/public/**", "/index.html", "sessionCheck.js","returnButton.js")
						.permitAll()
						.anyRequest()
						.authenticated() // Secure other endpoints
				)
				.formLogin(form -> form
						.loginPage("/login")
						.loginProcessingUrl("/login")
						 .successHandler(successHandler())
						.failureUrl("/login?error=true"))
				.logout(logout -> logout.logoutSuccessUrl("/login?logout=true"))
				.sessionManagement()
					.sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED);
		return http.build();
	}

}
