// Function to search Pacientes as the user types
function searchPacientes(inputId, resultsListId, url) {
    const query = document.getElementById(inputId).value.trim();
    
    if (query.length < 3) {
        // Do not search if query is too short (e.g. less than 3 characters)
        document.getElementById(resultsListId).innerHTML = '';
        return;
    }

    fetch(`${url}?query=${query}`)
        .then(response => response.json())
        .then(data => {
            const resultsList = document.getElementById(resultsListId);
            resultsList.innerHTML = ''; // Clear previous results

            if (data && data.length > 0) {
                data.forEach(paciente => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${paciente.nombre} ${paciente.apellido}`;
                    listItem.setAttribute('data-id', paciente.id);  // Store paciente ID
                    listItem.onclick = () => selectPaciente(paciente.id, paciente.nombre, paciente.apellido, inputId, resultsListId);
                    resultsList.appendChild(listItem);
                });
            } else {
                resultsList.innerHTML = '<li>No se encontraron resultados</li>';
            }
        })
        .catch(error => {
            console.error('Error fetching pacientes:', error);
            document.getElementById(resultsListId).innerHTML = '<li>Error al buscar pacientes</li>';
        });
}

// Function to populate the pacienteId field when a paciente is selected
function selectPaciente(id, nombre, apellido, inputId, resultsListId) {
    // Populate pacienteId field with the selected paciente's ID
    document.getElementById(inputId.replace('Input', 'Id')).value = id;
    // Optionally display the full name for confirmation
    alert(`Paciente seleccionado: ${nombre} ${apellido} (ID: ${id})`);
    
    // Clear the results list after selection
    document.getElementById(resultsListId).innerHTML = '';
    document.getElementById(inputId).value = '';  // Optionally clear the input
}

