function searchPacientes(inputId, resultsListId, url) {
    const query = document.getElementById(inputId).value.trim();
    const resultsList = document.getElementById(resultsListId);
    
    // Hide the results list if input is empty or less than 3 characters
    if (query.length < 3) {
        resultsList.innerHTML = '';
        resultsList.style.display = 'none'; // Hide the dropdown
        return;
    }

    fetch(`${url}?query=${query}`)
        .then(response => response.json())
        .then(responseData => {
            resultsList.innerHTML = '';  // Clear the current list

            const pacientes = responseData.data;

            if (Array.isArray(pacientes) && pacientes.length > 0) {
                pacientes.forEach(paciente => {
                    const listItem = document.createElement('li');
                    listItem.textContent = `${paciente.nombre} ${paciente.apellido}`;
                    listItem.setAttribute('data-id', paciente.id);
                    listItem.onclick = () => selectPaciente(paciente.id, paciente.nombre, paciente.apellido, inputId, resultsListId);
                    resultsList.appendChild(listItem);
                });
                resultsList.style.display = 'block'; // Show the dropdown
            } else {
                resultsList.innerHTML = '<li>No se encontraron resultados</li>';
                resultsList.style.display = 'block'; // Show the dropdown with message
            }
        })
        .catch(error => {
            console.error('Error fetching pacientes:', error);
            resultsList.innerHTML = '<li>Error al buscar pacientes</li>';
            resultsList.style.display = 'block'; // Show the dropdown with error message
        });
}

function selectPaciente(id, nombre, apellido, inputId, resultsListId) {
    document.getElementById(inputId).setAttribute('data-id', id);
    document.getElementById(inputId).value = `${nombre} ${apellido}`; 
   // alert(`Paciente seleccionado: ${nombre} ${apellido} (ID: ${id})`);
    document.getElementById(resultsListId).innerHTML = '';
    document.getElementById(resultsListId).style.display = 'none'; // Hide the dropdown after selection
}
