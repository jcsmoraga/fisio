document.addEventListener('DOMContentLoaded', function () {
    const returnButton = document.getElementById('returnButton');
    if (returnButton) {
        returnButton.addEventListener('click', function () {
            // Redirect to index.html when the return button is clicked
            window.location.href = "index.html";  // Redirect to the main page
        });
    }
});
