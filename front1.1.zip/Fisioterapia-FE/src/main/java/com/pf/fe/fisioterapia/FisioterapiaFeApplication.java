package com.pf.fe.fisioterapia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FisioterapiaFeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FisioterapiaFeApplication.class, args);
	}

}
