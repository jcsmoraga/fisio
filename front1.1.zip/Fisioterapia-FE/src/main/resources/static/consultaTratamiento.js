function fetchTratamientos() {
	const pacienteId = document.getElementById('pacienteId').getAttribute('data-id').trim();  
    const tratamientosTable = document.getElementById('tratamientosTable');
    const tratamientosTableBody = document.getElementById('tratamientosTableBody');
    const errorMessageDiv = document.getElementById('errorMessage');
    
    // Hide previous error or table
    tratamientosTable.classList.add('hidden');
    errorMessageDiv.classList.add('hidden');
    
    if (!pacienteId) {
        errorMessageDiv.textContent = 'Por favor, selecciona un paciente.';
        errorMessageDiv.classList.remove('hidden');
        return;
    }

    fetch(`http://localhost:8082/tratamientos/search?pacienteId=${pacienteId}`, {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa('admin:F1510Ter@p145!') 
        }
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('No autorizado o error en el servidor');
        }
        return response.json();
    })
    .then(data => {
        if (data && data.length > 0) {
            tratamientosTableBody.innerHTML = ''; 

            data.forEach(tratamiento => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${tratamiento.fisioterapeutaNombre}</td>
                    <td>${tratamiento.tipoTratamiento}</td>
                    <td>${new Date(tratamiento.fechaInicio).toLocaleDateString()}</td>
                    <td>${tratamiento.estado}</td>
                    <td>${tratamiento.descripcion}</td>
                `;
                tratamientosTableBody.appendChild(row);
            });

            tratamientosTable.classList.remove('hidden');
            document.getElementById('exportCsvButton').classList.remove('hidden');
            document.getElementById('exportPdfButton').classList.remove('hidden');
        } else {
            errorMessageDiv.textContent = 'No se encontraron tratamientos para este paciente.';
            errorMessageDiv.classList.remove('hidden');
        }
    })
    .catch(error => {
        errorMessageDiv.textContent = 'Ocurrió un error al consultar los tratamientos: ' + error.message;
        errorMessageDiv.classList.remove('hidden');
    });
}
function exportToCsv() {
    const tratamientosTableBody = document.getElementById('tratamientosTableBody');
    let csvContent = "Fisioterapeuta, Tipo de Tratamiento, Fecha de Inicio, Estado, Descripción\n";

  
    Array.from(tratamientosTableBody.rows).forEach(row => {
        const rowData = Array.from(row.cells).map(cell => cell.textContent);
        csvContent += rowData.join(",") + "\n";
    });

  
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'tratamientos.csv';
    link.click();
}

function exportToPdf() {
    const { jsPDF } = window.jspdf;  // Access the jsPDF class from the window object

    const tratamientosTable = document.getElementById('tratamientosTable');
    const doc = new jsPDF();
    
    // Title for the PDF
    doc.setFontSize(18);
    doc.text('Lista de Tratamientos', 14, 20);

    // Get table headers
    const headers = ["Fisioterapeuta", "Tipo de Tratamiento", "Fecha de Inicio", "Estado", "Descripción"];

    // Get table data rows
    const tableData = [];
    Array.from(tratamientosTable.rows).slice(1).forEach(row => {
        const rowData = Array.from(row.cells).map(cell => cell.textContent);
        tableData.push(rowData);
    });

    // Add the table to the PDF
    doc.autoTable({
        head: [headers],
        body: tableData,
        startY: 30, // Start the table 30mm down from the top
        theme: 'grid', // Use grid theme for better styling
    });

    // Save the PDF to a file
    doc.save('tratamientos.pdf');
}


