document.getElementById('fisioterapeutaForm').addEventListener('submit', function (e) {
    e.preventDefault();
	


    // Clear any previous message
    const messageDiv = document.getElementById('message');
    messageDiv.className = 'hidden';
    messageDiv.textContent = '';

    // Retrieve form values
    const nombre = document.getElementById('nombre').value.trim();
	const apellido = document.getElementById('apellido').value.trim();
    const especialidad = document.getElementById('especialidad').value.trim();
    const telefono = document.getElementById('telefono').value.trim();
    const email = document.getElementById('email').value.trim();

    // Validate inputs
    if (!nombre || !especialidad || !telefono || !email) {
        messageDiv.textContent = 'Por favor, completa todos los campos obligatorios.';
        messageDiv.className = 'error';
        return;
    }

    // Prepare the data to send to the backend
    const fisioterapeutaData = {
        nombre: nombre,
		apellido: apellido,
        especialidad: especialidad,
        telefono: telefono,
        email: email
    };

    // Send the data using fetch API
    fetch('http://localhost:8082/fisioterapeutas', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa('admin:F1510Ter@p145!') // Basic Auth header
        },
        body: JSON.stringify(fisioterapeutaData)
    })
    .then(response => response.json()) 
    .then(data => {
        // Check if the response contains the expected data object
        if (data && data.data) {
            const fisioterapeuta = data.data;  // Extract the fisioterapeuta data from the response
            messageDiv.textContent = `¡Fisioterapeuta ${fisioterapeuta.nombre} registrado exitosamente con ID ${fisioterapeuta.id}!`;
            messageDiv.className = 'success';

            // Optionally, clear the form
            document.getElementById('fisioterapeutaForm').reset();
        } else {
            messageDiv.textContent = 'Ocurrió un error al registrar el fisioterapeuta.';
            messageDiv.className = 'error';
        }
    })
    .catch(error => {
        // Handle errors (network issues, server errors, etc.)
        messageDiv.textContent = 'Ocurrió un error al registrar el fisioterapeuta: ' + error.message;
        messageDiv.className = 'error';
    });
});