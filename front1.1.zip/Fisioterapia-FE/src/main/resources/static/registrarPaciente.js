document.getElementById('patientForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const messageDiv = document.getElementById('message');
    messageDiv.className = 'hidden';
    messageDiv.textContent = '';

   
    const fullName = document.getElementById('fullName').value.trim();
    const apellido = document.getElementById('apellido').value.trim();
    const dob = document.getElementById('dob').value.trim();
    const dni = document.getElementById('dni').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const direccion = document.getElementById('direccion').value.trim(); 

   
    const fechaRegistro = new Date().toISOString().slice(0, 19);  

   
    if (!fullName || !dob || !dni || !email || !phone) {
        messageDiv.textContent = 'Por favor, completa todos los campos obligatorios.';
        messageDiv.className = 'error';
        return;
    }

   
    const parsedDob = new Date(dob);
    if (isNaN(parsedDob)) {
        messageDiv.textContent = 'Por favor, ingresa una fecha de nacimiento válida.';
        messageDiv.className = 'error';
        return;
    }

   
    const dobFormatted = parsedDob.toISOString().slice(0, 10); 

    // Create patient data object
    const patientData = {
        nombre: fullName,
        apellido: apellido,
        fechaNacimiento: dobFormatted,  
        dni: dni,
        email: email,
        telefono: phone,
        direccion: direccion,
        fechaRegistro: fechaRegistro  
    };

   
    console.log('Sending data:', patientData);

    
    fetch('http://localhost:8082/paciente', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa('admin:F1510Ter@p145!') 
        },
        body: JSON.stringify(patientData)
    })
    .then(response => {
        console.log('Response received:', response);  
        return response.json();  
    })
    .then(data => {
        console.log('Response data:', data); 
        if (data && data.data) {
            const paciente = data.data;  
            messageDiv.textContent = `¡Paciente ${paciente.nombre} registrado exitosamente con ID ${paciente.id}!`;
            messageDiv.className = 'success';

           
            document.getElementById('patientForm').reset();
        } else {
            messageDiv.textContent = 'Ocurrió un error al registrar el paciente.';
            messageDiv.className = 'error';
        }
    })
    .catch(error => {
        messageDiv.textContent = 'Ocurrió un error al registrar el paciente: ' + error.message;
        messageDiv.className = 'error';
    });
});
