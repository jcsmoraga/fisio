document.getElementById('tratamientoForm').addEventListener('submit', function (e) {
    e.preventDefault();

    const messageDiv = document.getElementById('message');
    messageDiv.className = 'hidden';
    messageDiv.textContent = '';

    const pacienteId = document.getElementById('pacienteId').getAttribute('data-id');
    const fisioterapeutaId = document.getElementById('fisioterapeutaId').getAttribute('data-id');
    const tipoTratamiento = document.getElementById('tipoTratamiento').value.trim();
    let fechaInicio = document.getElementById('fechaInicio').value.trim();
    const descripcion = document.getElementById('descripcion').value.trim();
    const estado = document.getElementById('estado').value;

    if (fechaInicio) {
        const currentTime = new Date().toISOString().split('T')[1].split('.')[0]; 
        fechaInicio = fechaInicio + 'T' + currentTime;
    }

    if (!pacienteId || !fisioterapeutaId || !tipoTratamiento || !fechaInicio || !descripcion || !estado) {
        messageDiv.textContent = 'Por favor, completa todos los campos obligatorios.';
        messageDiv.className = 'error';
        return;
    }

    const tratamientoData = {
        paciente: { id: pacienteId },
        fisioterapeuta: { id: fisioterapeutaId },
        tipoTratamiento: tipoTratamiento,
        fechaInicio: fechaInicio,
        descripcion: descripcion,
        estado: estado
    };

    fetch('http://localhost:8082/tratamientos', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Basic ' + btoa('admin:F1510Ter@p145!')
        },
        body: JSON.stringify(tratamientoData)
    })
    .then(response => response.json())  
    .then(response => {
        console.log('Response data:', response);  
        if (response && response.data) {
            messageDiv.textContent = `¡Tratamiento registrado correctamente con ID ${response.data.id || 'Unknown'}!`;
            messageDiv.className = 'success';

            document.getElementById('tratamientoForm').reset();
        } else {
            messageDiv.textContent = 'Ocurrió un error al registrar el tratamiento.';
            messageDiv.className = 'error';
        }
    })
    .catch(error => {
        messageDiv.textContent = 'Ocurrió un error al registrar el tratamiento: ' + error.message;
        messageDiv.className = 'error';
    });
});
