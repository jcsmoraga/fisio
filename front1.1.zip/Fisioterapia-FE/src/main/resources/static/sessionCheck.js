fetch("http://localhost:8082/api/auth/check-session", {
    method: "GET",
    credentials: 'include'
})
.then(response => {
    if (response.status === 200) {
        console.log("Session is valid.");
        // Session is valid, do nothing or load the menu
    } else {
        console.log("Session is not valid.");
        // Redirect to login page if session is not valid
        window.location.href = "login.html";
    }
})
.catch(error => {
    console.error("Error checking session:", error);
    // In case of an error, assume session is invalid and redirect to login page
    window.location.href = "login.html";
});


