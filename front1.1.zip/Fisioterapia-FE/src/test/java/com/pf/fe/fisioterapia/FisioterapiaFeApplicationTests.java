package com.pf.fe.fisioterapia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FisioterapiaFeApplicationTests {

	@Test
	void contextLoads() {
	}

}
